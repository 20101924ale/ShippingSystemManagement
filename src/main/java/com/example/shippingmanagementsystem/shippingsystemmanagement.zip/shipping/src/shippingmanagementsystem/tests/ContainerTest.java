package shippingmanagementsystem.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContainerTest {

    @Test
    void removePallet() {
    }

    @Test
    void getContainerID() {
    }

    @Test
    void setContainerID() {
    }

    @Test
    void getContainerSize() {
    }

    @Test
    void setContainerSize() {
    }
}