package shippingmanagementsystem;



public class LinkList {
    private MyLinkedList<Port> port;
    private MyLinkedList<ContainerShips> ships;
    private MyLinkedList<Container> containers;

    public LinkList(MyLinkedList<Port> port) {
        this.port = port;
    }


//getter and setters


    public MyLinkedList<Port> getPort() {
        return port;
    }

    public void setPort(MyLinkedList<Port> port) {
        this.port = port;
    }
}


