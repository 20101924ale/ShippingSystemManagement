package shippingmanagementsystem.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PortTest {

    @Test
    void testToString() {
    }

    @Test
    void getName() {
    }

    @Test
    void setName() {
    }

    @Test
    void getPortCode() {
    }

    @Test
    void setPortCode() {
    }

    @Test
    void getCountry() {
    }

    @Test
    void setCountry() {
    }
}