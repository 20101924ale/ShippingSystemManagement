package shippingmanagementsystem.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContainerShipsTest {

    @Test
    void launch() {
    }

    @Test
    void dock() {
    }

    @Test
    void getName() {
    }

    @Test
    void setName() {
    }

    @Test
    void getShipID() {
    }

    @Test
    void setShipID() {
    }

    @Test
    void getCountry() {
    }

    @Test
    void setCountry() {
    }

    @Test
    void getPhotograph() {
    }

    @Test
    void setPhotograph() {
    }

    @Test
    void getPort() {
    }

    @Test
    void isAtSea() {
    }

    @Test
    void setAtSea() {
    }

    @Test
    void testToString() {
    }
}