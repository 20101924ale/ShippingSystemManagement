package shippingmanagementsystem.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PalletTest {

    @Test
    void getDescription() {
    }

    @Test
    void setDescription() {
    }

    @Test
    void getQuantity() {
    }

    @Test
    void setQuantity() {
    }

    @Test
    void getUnitValue() {
    }

    @Test
    void setUnitValue() {
    }

    @Test
    void getTotalWeight() {
    }

    @Test
    void setTotalWeight() {
    }

    @Test
    void getTotalSize() {
    }

    @Test
    void setTotalSize() {
    }
}