package shippingmanagementsystem.tests;

import static org.junit.jupiter.api.Assertions.*;

class MyLinkedListTest {

    @org.junit.jupiter.api.Test
    void iterator() {
    }

    @org.junit.jupiter.api.Test
    void add() {
    }

    @org.junit.jupiter.api.Test
    void remove() {
    }

    @org.junit.jupiter.api.Test
    void isEmpty() {
    }

    @org.junit.jupiter.api.Test
    void listAllPorts() {
    }

    @org.junit.jupiter.api.Test
    void listAllShips() {
    }

    @org.junit.jupiter.api.Test
    void listAllContainersAtPort() {
    }

    @org.junit.jupiter.api.Test
    void listAllPalletsAtPort() {
    }

    @org.junit.jupiter.api.Test
    void listAllShipLocations() {
    }

    @org.junit.jupiter.api.Test
    void listPalletValue() {
    }
}